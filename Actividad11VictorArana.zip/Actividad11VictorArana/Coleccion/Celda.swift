//
//  Celda.swift
//
//
//  Created by Victor Arana.
//

import UIKit

class Celda: UICollectionViewCell {
    @IBOutlet weak var imagenNum: UIImageView!
}
