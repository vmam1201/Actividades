//
//  ColeccionVC.swift
//
//
//  Created by Victor Arana.
//

import UIKit


private let reuseIdentifier = "celda"

class ColeccionVC: UICollectionViewController {

    var imgNum:[String] = []
    let numeros:[String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        for valor in 0...19{
            imgNum.append("\(valor+1)")
        }
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }

    // MARK: UICollectionViewDataSource
    override func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        imgNum.count
    }
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier, for: indexPath) as! Celda
        cell.imagenNum.image = UIImage(named: imgNum[indexPath.row])
        return cell
    }
    

}
